# cst-vtu-calculator
This is cst vtu calculator which calculates the SGPA/CGPA/with PERCENTAGE 
